package kailey.jndn.blockndn.sys;

public interface CheckBlock {
	public boolean isBlockLegal(Block block, byte[] prevBlockHash);
}
