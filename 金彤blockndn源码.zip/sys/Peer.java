package kailey.jndn.blockndn.sys;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.Date;

import net.named_data.jndn.Face;
import net.named_data.jndn.Interest;
import net.named_data.jndn.Name;
import net.named_data.jndn.encoding.EncodingException;

public class Peer {


public static void write(long l) {
	FileWriter fw = null;
	try {
		File f=new File("log.txt");
		fw = new FileWriter(f, true);
	} catch (IOException e) {
		e.printStackTrace();
	}
	PrintWriter pw = new PrintWriter(fw);
	pw.println(l);
	pw.flush();
	try {
		fw.flush();
		pw.close();
		fw.close();
	} catch (IOException e) {
		e.printStackTrace();
	}
}

	public static void main(String[] args) {
		
		File file = new File("log.txt");  
	        try {  
	            file.createNewFile(); // 创建文件  
	        } catch (IOException e) {  
	            // TODO Auto-generated catch block  
	            e.printStackTrace();  
	        }  
		
		
		BlockChainProxy blockChainProxy;
		ExecutorService executor;
		Map<String, Producer> producerMap;
		// Allocate space for a blockchain, load the genesis block and create a blockchainproxy to manage this.
		blockChainProxy = new BlockChainProxy();
		executor = Executors.newFixedThreadPool(10);
		producerMap = new HashMap<String, Producer>();

		VolumeProduction vp = new VolumeProduction();
		vp.initVolumeProduction(blockChainProxy, executor, producerMap);
			
		Face face = new Face();
		byte[] flag = null;
		
		System.out.println("System running...");
		System.out.println(" [Time] :" + new Date().getTime());
		System.out.println("[LOCAL] : 0th Block : [Block Digest] : " + Utils.bytesToHexString(blockChainProxy.getBlockChainGenesisHash()));
		System.out.println("[LOCAL] :Latest Block:[Block Digest] : " + Utils.bytesToHexString(blockChainProxy.getPreviousHash()));
		write(0);
		write(new Date().getTime());
		
		boolean minerFlag = false;	
		// TODO: into while and Miner finish creating a new block, but the minerFlag is still true ,waste a loop time
		while(true){
					
			// Miner hasn't create a new block yet & Nobody has created yet.
			if(Arrays.equals(flag, blockChainProxy.getPreviousHash()))
				minerFlag = true;
			else 
				minerFlag = false;
			// Update flag value.
			flag = blockChainProxy.getPreviousHash();		
			String prefix = String.join("/", Configure.blockNDNGetBlockPrefix, Utils.bytesToHexString(flag));			
			Consumer consumer = new Consumer();		
			Interest interest = new Interest(new Name(prefix));
			interest.setInterestLifetimeMilliseconds(1000);
			try {
				// TODO Retransmission after timeout: like TCP/IP windows : exponential order?
				while(!consumer.getNewBlock && consumer.timeoutCount > 0 ){
					face.expressInterest(interest, consumer, consumer);		
					face.processEvents();
					Thread.sleep(1000);
				}
				
				// Get a new block, use BlockChainProxy Class to check it. If the block is legal, append to local blockchain.
				if(consumer.getNewBlock){
					//  The new block is illegal.
					if(!blockChainProxy.addBlock(consumer.block)){
						System.out.println("**Get a new block**:[ERROR] : new block is illegal.");
						System.out.println("               [Block Name] :" + Utils.bytesToHexString(consumer.block.prevBlock));
						continue;
					}
					// The Block is legal , append to the local blockchain.Create a new producer.
					String prefixNewBlock = String.join("/", Configure.blockNDNGetBlockPrefix, Utils.bytesToHexString(consumer.block.prevBlock));
					if(!producerMap.containsKey(prefix)){
						Producer producer = new Producer(consumer.block, prefixNewBlock);
						executor.execute(producer);
						producerMap.put(prefixNewBlock, producer);	
					}
					
					write(blockChainProxy.getBlockHeight());
					write(new Date().getTime());
					
					System.out.println("[LOCAL] :  Store a new block: [SUCCESSFUL] : Store Successfully Into Blockchain.");
					System.out.println("                      [Time]:" + new Date().getTime());
					System.out.println("                    [height]:" + blockChainProxy.getBlockHeight());
					System.out.println("              [Block Prefix]: " + Utils.bytesToHexString(consumer.block.prevBlock));
					System.out.println("            [Previous Block]: " + Utils.bytesToHexString(consumer.block.prevBlock));
					System.out.println("              [Block Digest]: " + Utils.bytesToHexString(Utils.digestsha256(consumer.block)));
					System.out.println("                [Block Size]: " + consumer.block.blockSize);
					System.out.println("               [Transaction]: " + consumer.block.s);
					System.out.println("                     [Nonce]: " + consumer.block.nonce);
					continue;
				}			
				// Timeout: Network Congestion & No Such a Data packet
				// whether miner thread has been called in the latest loop.
				if(!minerFlag){
					if(consumer.timeoutCount < 0 || consumer.timeoutCount ==0){			
						// The next block doesn't exist yet.
						// TODO If timeout, ask other nodes through modified ChronoSync? 
						Runnable miner = new Miner(flag,blockChainProxy,producerMap);
						Thread thread = new Thread(miner);
						thread.start();					
					}
				}				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("Producer: IOException in sending data " + e.getMessage());
			} catch (EncodingException e) {
				// TODO Auto-generated catch block
				System.out.println("Producer: EncodingException in sending data " + e.getMessage());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	
		
	}

}
